export default [
  {
    id: 1,
    title: "First Order Discount",
    image: "https://source.unsplash.com/400x300/?food"
  },
  {
    id: 2,
    title: "Vegan Discount",
    image: "https://source.unsplash.com/400x300/?salad"
  },
  {
    id: 3,
    title: "Free Ice Cream",
    image: "https://source.unsplash.com/400x300/?icecream"
  }
];
