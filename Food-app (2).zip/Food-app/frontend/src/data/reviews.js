export default [
  {
    id: 1,
    name: "John",
    text: "Amazing food and fast delivery!"
  },
  {
    id: 2,
    name: "Sarah",
    text: "Great taste and packaging."
  },
  {
    id: 3,
    name: "Alex",
    text: "Highly recommend this restaurant!"
  }
];
